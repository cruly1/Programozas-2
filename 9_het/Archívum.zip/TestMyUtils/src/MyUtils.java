public class MyUtils {
    private MyUtils() {}

    public static int duplaz(int n) {
        return 2 * n;
    }

    public static int strlen(String s) {
        return s.length();
    }
}
